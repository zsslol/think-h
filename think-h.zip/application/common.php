<?php
// +----------------------------------------------------------------------
// | ThinkPHP [ WE CAN DO IT JUST THINK ]
// +----------------------------------------------------------------------
// | Copyright (c) 2006-2016 http://thinkphp.cn All rights reserved.
// +----------------------------------------------------------------------
// | Licensed ( http://www.apache.org/licenses/LICENSE-2.0 )
// +----------------------------------------------------------------------
// | Author: 流年 <liu21st@gmail.com>
// +----------------------------------------------------------------------

// 应用公共文件


function getCover($id){
    return \app\Admin\model\Upload::getFileUrl($id);
}

/**
 * 获取后台的配置参数
 * @param $name 配置名称, 可用（wx.name）取值。
 * @param string $default 无设置时的默认值
 * @return string
 */
function getAdminConfig($name = '', $default = ''){
    $is_get = \think\facade\Cache::tag('AdminConfig')->has('AdminConfig');
    if($is_get == false)\app\Admin\model\Config::setAdminConfig();
    $config = \think\facade\Cache::tag('AdminConfig')->get('AdminConfig');
    if(empty($name))return $config;
    $key = strpos($name, '.');
    if($key){
        $key_1 = substr($name, 0, $key);
        $key_2 = substr($name, $key+1);
        if(empty($key_2))return isset($config[$key_1]) ? $config[$key_1] : $default;
        return isset($config[$key_1][$key_2]) ? $config[$key_1][$key_2] : $default;
    } else {
        return isset($config[$name]) ? $config[$name] : $default;
    }
    return $config;
}