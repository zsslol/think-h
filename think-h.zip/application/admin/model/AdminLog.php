<?php

namespace app\Admin\model;

use think\Model;

class AdminLog extends Model
{
    //
    protected $table = 'admin_log';
}
